#!/usr/bin/env bash
# pyportfolios.com - double-click launcher for gbm-simulating-price-paths (Linux)
set -e
cd "$(dirname "$0")"

PY="$(command -v python3 || command -v python || true)"
if [ -z "$PY" ]; then
  echo "Python 3.10+ is required but was not found."
  echo "macOS: brew install python   |   Debian/Ubuntu: sudo apt install python3 python3-venv"
  read -r -p "Press Enter to close..." _
  exit 1
fi

if [ ! -d .venv ]; then
  echo "First run - creating an isolated environment (one-time, a few minutes)..."
  "$PY" -m venv .venv
fi
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r requirements.txt
echo "Opening the notebook in Jupyter Lab - keep this terminal open while you work."
python -m jupyter lab "gbm-simulating-price-paths.ipynb"
