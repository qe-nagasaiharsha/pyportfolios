pyportfolios.com - runnable notebook bundle
============================================

Notebook : copulas-tail-dependence.ipynb
Requires : Python 3.10+ and an internet connection on first run
           (dependencies install into a local .venv; market data downloads
           itself via yfinance). Nothing is installed system-wide.

How to run
----------
Windows : double-click  run-windows.bat
macOS   : double-click  run-mac.command
          (first time: right-click -> Open, to pass Gatekeeper; if it will
          not run:  chmod +x run-mac.command  in Terminal once)
Linux   : double-click  run-linux.sh  (or:  bash run-linux.sh)

Any OS, manually:
    python -m venv .venv
    .venv\Scripts\activate      (Windows)   |   source .venv/bin/activate (POSIX)
    pip install -r requirements.txt
    jupyter lab copulas-tail-dependence.ipynb

What it installs
----------------
  - numpy
  - pandas
  - scipy
  - matplotlib
  - yfinance
  - jupyterlab
  - statsmodels
  - seaborn

Troubleshooting
---------------
Windows: if the first run says "venv creation failed", the folder is nested
too deep (Windows path-length limit). Move this folder somewhere short,
e.g. C:
otebooks\, and double-click again.

Reproducibility
---------------
Random draws are seeded (default_rng(42)) so results match the article.
Yahoo occasionally restates adjusted closes; tiny third-decimal drifts are
the data vendor, not your machine.

(c) pyportfolios.com - where finance theory, coding & markets converge
