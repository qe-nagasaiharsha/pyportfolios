@echo off
rem pyportfolios.com - double-click launcher for gaussian-vs-t-copula
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
    echo Python 3.10+ is required but was not found on PATH.
    echo Install it from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^).
    pause
    exit /b 1
)
if not exist ".venv" (
    echo First run - creating an isolated environment ^(one-time, a few minutes^)...
    python -m venv .venv || (echo venv creation failed & pause & exit /b 1)
)
call ".venv\Scripts\activate.bat"
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r requirements.txt || (echo dependency install failed & pause & exit /b 1)
echo Opening the notebook in Jupyter Lab - keep this window open while you work.
python -m jupyter lab "gaussian-vs-t-copula.ipynb"
pause
